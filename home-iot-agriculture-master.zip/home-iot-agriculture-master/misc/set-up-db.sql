use ivofarm;
alter database ivofarm character set utf8mb4 collate utf8mb4_general_ci;
set names utf8mb4 collate utf8mb4_general_ci;


set @user_group__admin = 1;
set @user_group__techmod = 2;
set @user_group__customer = 3;




create table user_group(
	id int primary key auto_increment,
	name varchar(255) not null,
	full_name varchar(255) not null
);

insert into user_group(id, name, full_name) values
	(@user_group__admin, 'admin', 'Administrators'),
	(@user_group__techmod, 'techmod', 'Technical moderators'),
	(@user_group__customer, 'customer', 'Customers');




create table user_group_permission(
	id int primary key auto_increment,
	permission int not null
);

create index user_group_permission__permission on user_group_permission(permission);





create table user(
	id int primary key auto_increment,
	login varchar(255) not null,
	full_name varchar(255) not null,
	password varchar(65) not null,
	user_group int not null,
	create_time datetime not null default now(),
	last_login datetime,

	constraint foreign key(user_group) references user_group(id)
);

insert into user(login, full_name, password, user_group) values
	('root', 'root', sha2('root', 256), @user_group__admin);

create index user__login on user(login);
create index user__group on user(user_group);



create table plant_type(
	id int primary key auto_increment,
	name varchar(255) not null
);

create index plant_type__name on plant_type(name);

insert into plant_type(name) values('Rau cải'), ('Xà lách');



create table frame(
	id int primary key auto_increment,
	user int not null,
	name varchar(255) not null,
	create_time datetime not null default now(),

	constraint foreign key(user) references user(id)
);

create index frame__user on frame(user);





create table device_type(
  id int primary key auto_increment,
  name varchar(255) not null
);

insert into device_type(name) values('ESP32');




create table device(
	id int primary key auto_increment,
	frame int not null,
	device_type int not null,
	password varchar(65) not null,
	security_code varchar(255),

	constraint foreign key(frame) references frame(id),
	constraint foreign key(device_type) references device_type(id)
);

create index device__type on device(device_type);




create table crop(
	id int primary key auto_increment,
	frame int not null,
	plant_type int not null,
	name varchar(255) not null,
	start_time datetime not null default now(),
	end_time datetime,

	constraint foreign key(frame) references frame(id),
	constraint foreign key(plant_type) references plant_type(id)
);

create index crop__frame on crop(frame);
create index crop__plant_type on crop(plant_type);





create table sensor_type(
	id int primary key auto_increment,
	name varchar(255) not null
);

create index sensor_type__name on sensor_type(name);

insert into sensor_type(name) values('pH'), ('temperature'), ('humidity'), ('tds'), ('light'), ('water level');



create table sensor(
	id int primary key auto_increment,
	name varchar(255) not null,
	device int not null,
	sensor_type int not null,

	constraint foreign key(device) references device(id),
	constraint foreign key(sensor_type) references sensor_type(id)
);

create index sensor__name on sensor(name);
create index sensor__device on sensor(device);
create index sensor__sensor_type on sensor(sensor_type);




create table sensor_data(
	id int primary key auto_increment,
	sensor int not null,
	value float,
	`time` datetime not null default now(),

	constraint foreign key(sensor) references sensor(id)
);

create index sensor_data__sensor on sensor_data(sensor);
create index sensor_data__time on sensor_data(`time`);







create table actuator_type(
	id int primary key auto_increment,
	name varchar(255) not null
);

create index actuator_type__name on actuator_type(name);

insert into actuator_type(name) values('pump'), ('lamp');



create table actuator(
	id int primary key auto_increment,
	name varchar(255) not null,
	device int not null,
	actuator_type int not null,

	constraint foreign key(device) references device(id),
	constraint foreign key(actuator_type) references actuator_type(id)
);

create index actuator__name on actuator(name);
create index actuator__device on actuator(device);
create index actuator__actuator_type on actuator(actuator_type);




create table command(
	id int primary key auto_increment,
	device int not null,
	params varchar(512),
	`time` datetime not null default now(),
	is_done bool not null default false,

	constraint foreign key(device) references device(id)
);

create index command__device on command(device);
create index command__time on command(`time`);






-- create sample data

insert into user(id, login, full_name, password, user_group) values
	(2, 'kien', 'Trung Kiên', sha2('kien', 256), @user_group__customer),
	(3, 'hung', 'Ngọc Hưng', sha2('hung', 256), @user_group__customer);
	
insert into frame(id, user, name) values
	(1, 2, "Kien's farm"),
	(2, 3, "Hung's farm");

insert into device(device_type, frame, password) values
  (1, 1, sha2('esp32', 256)),
  (1, 2, sha2('esp32', 256));

insert into sensor(name, device, sensor_type) values
	('pH', 1, 1),
	('temperature', 1, 2),
	('humidity', 1, 3),
	('tds', 1, 4),
	('pH', 2, 1),
	('temperature', 2, 2),
	('humidity', 2, 3),
	('tds', 2, 4);
	
insert into actuator(name, device, actuator_type) values
	('pump', 1, 1),
	('lamp', 1, 2),
	('pump', 2, 1),
	('lamp', 2, 2);
	
insert into crop(frame, plant_type, name) values
	(1, 1, 'Happy farming'),
	(2, 2, 'Lucky farming');
	
	
delimiter ;;
create procedure add_sample_sensor_data(sensor int, num int, minr double, maxr double)
begin
	set @ii = num;
	repeat
		insert into sensor_data(sensor, value, `time`) select sensor, minr+rand()*(maxr-minr), now()-interval @ii minute;
		set @ii = @ii - 1;
	until @ii <= 0 end repeat;
end;;
delimiter ;

call add_sample_sensor_data(1, 1000, 4, 10);
call add_sample_sensor_data(2, 1000, 10, 45);
call add_sample_sensor_data(3, 1000, 20, 100);
call add_sample_sensor_data(4, 1000, 10, 20);
call add_sample_sensor_data(5, 1000, 4, 10);
call add_sample_sensor_data(6, 1000, 10, 45);
call add_sample_sensor_data(7, 1000, 20, 100);
call add_sample_sensor_data(8, 1000, 10, 20);

drop procedure add_sample_sensor_data;