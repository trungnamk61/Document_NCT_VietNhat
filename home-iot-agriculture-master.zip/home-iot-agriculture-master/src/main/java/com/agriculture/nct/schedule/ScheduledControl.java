package com.agriculture.nct.schedule;

import com.agriculture.nct.model.Command;
import com.agriculture.nct.services.MqttControlService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Component
@Log4j2
public class ScheduledControl {

    private MqttControlService mqttControlService;
    private int commandCount = 0;

    @Autowired
    public ScheduledControl(MqttControlService mqttControlService) {
        this.mqttControlService = mqttControlService;
    }

    @Scheduled(fixedRateString = "${scheduling.control.fixedRate}")
    public void sendControl() throws IOException {
        InputStream jsonTest = new ClassPathResource("static/control_test.json").getInputStream();
        ObjectMapper mapper = new ObjectMapper();
        List<Command> commandJsonList = mapper.readValue(jsonTest, new TypeReference<List<Command>>() {
        });
        for (Command command : commandJsonList) {
            command.setCommand_no(commandCount++);
            mqttControlService.publishCommand(command);
            log.info("Scheduled control sent a command : " + command.toString());
        }
    }
}
