package com.agriculture.nct;

import com.agriculture.nct.database.connection.DBServices;
import com.agriculture.nct.database.data.Command;
import com.agriculture.nct.database.data.Sensor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.scheduling.annotation.EnableScheduling;

import java.text.SimpleDateFormat;
import java.util.List;

@SpringBootApplication
@EnableScheduling
public class NctApplication {



    private static void kienTest() {
        DBServices db = new DBServices();

        System.out.println("Authentication...");
        boolean ok = db.verifyDeviceById(1, "esp32");
        System.out.println(ok ? "ok" : "failed");
        if (!ok) return;

        System.out.println("Set security code...");
        db.updateDeviceSecurityCodeById(1, "gestapo");

        System.out.println("Get security code back...");
        System.out.println(db.getDeviceSecurityCodeById(1));

        System.out.println("Push sensor data...");
        db.addSensorData(1, Sensor.TEMPERATURE, 35.53);
        db.addSensorData(1, 1, 34.33, 76.33, 6.55, 10);

        System.out.println("Add command...");
        db.addCommand(1, "[{actuator:1, action:'on'}, {'actuator':2, action:'off'}]");

        System.out.println("Get all commands...");
        List<Command> cmds = db.getAllCommands(1, true);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        for (Command item : cmds) {
            System.out.printf("- %d, %d, %s, %s%n",
                    item.getId(),
                    item.getDeviceId(),
                    sdf.format(item.getTime()),
                    item.getParams());
        }
    }


    public static void main(String[] args) {
        //kienTest();

        SpringApplication.run(NctApplication.class, args);
        //new MqttAuthenticationService();
        //new MqttCollectService();
    }
}
