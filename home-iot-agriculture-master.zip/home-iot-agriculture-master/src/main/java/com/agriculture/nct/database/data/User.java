package com.agriculture.nct.database.data;

import java.util.Date;

public class User {
	private int id;
	private String login;
	private String fullName;
	private int userGroupId;
	private Date createTime;
	private Date lastLogin;
	
	public User(int id, String login, String fullName, int userGroupId, Date createTime, Date lastLogin) {
		this.id = id;
		this.login = login;
		this.fullName = fullName;
		this.userGroupId = userGroupId;
		this.createTime = createTime;
		this.lastLogin = lastLogin;
	}
	
	public int getId() {
		return id;
	}

	
	public String getLogin() {
		return login;
	}

	
	public String getFullName() {
		return fullName;
	}

	
	public int getUserGroupId() {
		return userGroupId;
	}

	
	public Date getCreateTime() {
		return createTime;
	}

	
	public Date getLastLogin() {
		return lastLogin;
	}
}
