package com.agriculture.nct.database.connection;

import com.agriculture.nct.database.data.*;


public class DBServices extends DBCommon {
	

}
