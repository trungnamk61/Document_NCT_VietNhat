package com.agriculture.nct.database.data;

public class Actuator {
	public final static int PUMP = 1;
	public final static int LAMP = 2;

	static public String nameByType(int type) {
		switch (type) {
		case PUMP: return "Pump";
		case LAMP: return "Lamp";
		}

		return "";
	}




	private int id;
	private String name;
	private int deviceId;
	private int type;

	public Actuator(int id, String name, int deviceId, int type) {
		this.id = id;
		this.name = name;
		this.deviceId = deviceId;
		this.type = type;
	}
	
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public int getDeviceId() {
		return deviceId;
	}
	
	public int getType() {
		return type;
	}
}
