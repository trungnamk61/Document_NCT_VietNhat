package com.agriculture.nct.database.data;

import java.util.Date;

public class SensorData {
	private int id;
	private int sensorId;
	private double value;
	private Date timestamp;
	
	public SensorData(int id, int sensorId, double value, Date timestamp) {
		this.id = id;
		this.sensorId = sensorId;
		this.value = value;
		this.timestamp = timestamp;
	}
	
	public int getId() {
		return id;
	}
	
	public int getSensorId() {
		return sensorId;
	}
	
	public double getValue() {
		return value;
	}
	
	public Date getTimestamp() {
		return timestamp;
	}
}
