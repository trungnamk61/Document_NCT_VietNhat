package com.agriculture.nct.database.data;

import java.util.Date;

public class Frame {
	private int id;
	private int userId;
	private String name;
	private Date createTime;
	
	public Frame(int id, int userId, String name, Date createTime) {
		this.id = id;
		this.userId = userId;
		this.name = name;
		this.createTime = createTime;
	}
	
	public int getId() {
		return id;
	}
	
	public int getUserId() {
		return userId;
	}
	
	public String getName() {
		return name;
	}
	
	public Date getCreateTime() {
		return createTime;
	}
}
