package com.agriculture.nct.controller;

import com.agriculture.nct.model.Command;
import com.agriculture.nct.services.MqttControlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * This class implements a REST API for our application.
 */
@RestController
@RequestMapping("/device")
public class DeviceController {

    private MqttControlService mqttControlService;

    @Autowired
    public DeviceController(MqttControlService mqttControlService) { this.mqttControlService = mqttControlService;
    }

    @PostMapping("/control")
    ResponseEntity controlDevice(@RequestBody Command command) {
        return mqttControlService.publishCommand(command);
    }

}
