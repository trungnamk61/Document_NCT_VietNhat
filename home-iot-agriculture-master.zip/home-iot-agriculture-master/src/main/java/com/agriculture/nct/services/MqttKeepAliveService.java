package com.agriculture.nct.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.net.ConnectException;
import java.util.ArrayList;
import java.util.List;

@Service
@Log4j2
public class MqttKeepAliveService implements MqttCallback {
    private static String TAG = "[MQTT_KEEP_ALIVE]: ";
    private String keepAliveTopic = "nct_keep_alive";
    private int qos = 2; //AT_LEAST_ONCE
    private String broker = "tcp://broker.hivemq.com:1883";
    private String clientId = "SERVER_KEEP_ALIVE_SERVICE_ID";
    private boolean[] statusList = new boolean[1024];

    private MqttClient mqttKeepAlive = null;

    public MqttKeepAliveService() {
        MemoryPersistence persistence = new MemoryPersistence();
        try {
            mqttKeepAlive = new MqttClient(broker, clientId, persistence);
            mqttKeepAlive.connect(new MqttConnectOptions());
            log.info(TAG + "Connecting to broker: " + broker);
            mqttKeepAlive.setCallback(this);
            if (mqttKeepAlive.isConnected())
                log.info(TAG + "Connected. Subscribing the keep alive topic ...");
            mqttKeepAlive.subscribe(keepAliveTopic, qos);
        } catch (MqttException me) {
            me.printStackTrace();
        }
    }

    @Override
    public void connectionLost(Throwable arg0) {
        log.warn(TAG + "Connection lost");
        while (!mqttKeepAlive.isConnected()) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                log.info(TAG + "Trying to connect again");
                mqttKeepAlive.connect();
                mqttKeepAlive.setCallback(this);
                if (mqttKeepAlive.isConnected())
                    log.info(TAG + "Connected. Subscribing the keep alive topic ...");
                mqttKeepAlive.subscribe(keepAliveTopic, qos);
            } catch (MqttException e) {
                e.printStackTrace();
            }
        }
        log.info(TAG + "Connected again");
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        String msg = new String(message.getPayload());
        log.info(TAG + "Received message: " + msg);
        if (!topic.equals(keepAliveTopic)) {
            log.info(TAG + "Message Arrived not belong to keep alive topic");
        } else {
            try {

                ObjectMapper mapper = new ObjectMapper();
                int id = mapper.readTree(msg).get("id").intValue();
                log.info(TAG + "Received a keep alive message for device_" + id);
                statusList[id] = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
    }

    @Scheduled(fixedRateString = "${scheduling.keepalive.fixedRate}")
    private void keepAlive() {
        List<Integer> activeList = new ArrayList<Integer>();
        int count = 0, index = 0;
        for (boolean status : statusList) {
            if (status) {
                count++;
                activeList.add(index);
            }
            index++;
        }
        log.info(TAG + "There are " + count + " active devices : " + activeList.toString());
        // Restart list
        statusList = new boolean[1024];
    }
}

