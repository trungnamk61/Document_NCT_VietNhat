package com.agriculture.nct.database.connection;

import java.sql.*;
import java.util.*;

import javax.sql.DataSource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.agriculture.nct.database.data.*;

public class DBCommon {

	protected static DataSource dataSource = null;
	protected static JdbcTemplate jdbc = null;


	public DBCommon() {
		if (jdbc != null) return;

		DriverManagerDataSource mysqlDS = new DriverManagerDataSource();
		mysqlDS.setDriverClassName("com.mysql.cj.jdbc.Driver");
		mysqlDS.setUrl("jdbc:mysql://localhost:3306/ivofarm");
		mysqlDS.setUsername("ivofarm");
		mysqlDS.setPassword("ivofarm");

		dataSource = mysqlDS;
		jdbc = new JdbcTemplate(dataSource);
	}


	protected class UserMapper implements RowMapper<User> {
		public User mapRow(ResultSet rs, int rn) throws SQLException {
			return new User(rs.getInt("id"),
							rs.getString("login"),
							rs.getString("full_name"),
							rs.getInt("user_group"),
							rs.getTimestamp("create_time"),
							rs.getTimestamp("last_login"));
		}
	}

	protected class FrameMapper implements RowMapper<Frame> {
		public Frame mapRow(ResultSet rs, int rn) throws SQLException {
			return new Frame(rs.getInt("id"),
					rs.getInt("user"),
					rs.getString("name"),
					rs.getTimestamp("create_time"));
		}
	}

	protected class DeviceMapper implements RowMapper<Device> {
		public Device mapRow(ResultSet rs, int rn) throws SQLException {
			return new Device(rs.getInt("id"),
							rs.getInt("frame"),
							rs.getInt("device_type"),
							rs.getString("password"),
							rs.getString("security_code"));
		}
	}
	
	protected class SensorMapper implements RowMapper<Sensor> {
		public Sensor mapRow(ResultSet rs, int rn) throws SQLException {
			return new Sensor(rs.getInt("id"),
							rs.getString("name"),
							rs.getInt("device"),
							rs.getInt("sensor_type"));
		}
	}

	protected class ActuatorMapper implements RowMapper<Actuator> {
		public Actuator mapRow(ResultSet rs, int rn) throws SQLException {
			return new Actuator(rs.getInt("id"),
					rs.getString("name"),
					rs.getInt("device"),
					rs.getInt("sensor_type"));
		}
	}

	protected class SensorDataMapper implements RowMapper<SensorData> {
		public SensorData mapRow(ResultSet rs, int rn) throws SQLException {
			return new SensorData(rs.getInt("id"),
							rs.getInt("sensor"),
							rs.getDouble("value"),
							rs.getTimestamp("time"));
		}
	}
	
	protected class CommandMapper implements RowMapper<Command> {
		public Command mapRow(ResultSet rs, int rn) throws SQLException {
			return new Command(rs.getInt("id"),
							rs.getInt("device"),
							rs.getString("params"),
							rs.getTimestamp("time"),
							rs.getBoolean("is_done"));
		}
	}
	
	
	
	
	
	

	public List<User> getAllUsers() {
		return jdbc.query("select * from user order by create_time",
				new UserMapper());
	}
	
	public User getUserById(int id) {
		return jdbc.queryForObject("select * from user where id = ?",
				new Object[] {id},
				new UserMapper());
	}
	
	public List<Frame> getFramesOfUser(int userId) {
		return jdbc.query("select * from frame where user = ?",
				new Object[] {userId},
				new FrameMapper());
	}

	public Frame getFrameById(int id) {
		return jdbc.queryForObject("select * from frame where id = ?",
				new Object[] {id},
				new FrameMapper());
	}

	public List<Device> getDevicesOfFrame(int frameId) {
		return jdbc.query("select * from device where frame = ?",
				new Object[] {frameId},
				new DeviceMapper());
	}

	public Device getDeviceById(int id) {
		return jdbc.queryForObject("select * from device where id = ?",
				new Object[] {id},
				new DeviceMapper());
	}
	
	public List<Sensor> getSensorsOfDevice(int devId) {
		return jdbc.query("select * from sensor where device = ?",
				new Object[] {devId},
				new SensorMapper());
	}

	public Sensor getSensorById(int id) {
		return jdbc.queryForObject("select * from sensor where id = ?",
				new Object[] {id},
				new SensorMapper());
	}

	public List<Actuator> getActuatorsOfDevice(int devId) {
		return jdbc.query("select * from actuator where device = ?",
				new Object[] {devId},
				new ActuatorMapper());
	}

	public Actuator getActuatorById(int id) {
		return jdbc.queryForObject("select * from actuator where id = ?",
				new Object[] {id},
				new ActuatorMapper());
	}

	public List<SensorData> getSensorData(int sensorId) {
		return jdbc.query("select * from sensor_data where sensor = ? order by `time`",
				new Object[] {sensorId},
				new SensorDataMapper());
	}
	
	public boolean verifyDeviceById(int devId, String password) {
		return 1 == jdbc.queryForObject("select count(*) from device where id = ? and `password` = sha2(?,256)",
					new Object[] {devId, password},
					Integer.class);
	}
	
	public void updateDeviceSecurityCodeById(int devId, String code) {
		jdbc.update("update device set security_code = ? where id = ?",
				new Object[] {code, devId});
	}
	
	public String getDeviceSecurityCodeById(int devId) {
		return jdbc.queryForObject("select security_code from device where id = ?",
				new Object[] {devId},
				String.class);
	}
	
	public void addSensorData(int devId, int sensorType, double value) {
		jdbc.update("insert into sensor_data(sensor, value) select id, ? from sensor where device = ? and sensor_type = ?",
				new Object[] {value, devId, sensorType});
	}
	
	public void addSensorData(int devId, int packet_no, double temp, double humid, double ph, double tds) {
		addSensorData(devId, Sensor.TEMPERATURE, temp);
		addSensorData(devId, Sensor.HUMIDITY, humid);
		addSensorData(devId, Sensor.PH, ph);
		addSensorData(devId, Sensor.TDS, tds);
	}
	
	
	

	public void addCommand(int devId, String params) {
		jdbc.update("insert into command(device, params) values(?,?)",
				new Object[] {devId, params});
	}
	
	public List<Command> getAllCommands(int devId, boolean onlyNotDone) {
		if (onlyNotDone)
			return jdbc.query("select * from command where device = ? and not is_done order by time",
				new Object[] {devId},
				new CommandMapper());
		else return jdbc.query("select id, device, params, time, is_done from command where device = ? order by time",
				new Object[] {devId},
				new CommandMapper());
	}
	
	public Command getNextCommand(int devId) {
		return jdbc.queryForObject("select * from command where device = ? and not is_done order by time limit 1",
					new Object[] {devId},
					new CommandMapper());
	}

	public Command getLastCommand(int devId) {
		return jdbc.queryForObject("select * from command where device = ? and not is_done order by time desc limit 1",
					new Object[] {devId},
					new CommandMapper());
	}
}
