package com.agriculture.nct.database.data;

import java.util.Date;

public class Command {
	private int id;
	private int deviceId;
	private String params;
	private Date time;
	private boolean isDone;
	
	public Command(int id, int deviceId, String params, Date time, boolean isDone) {
		this.id = id;
		this.deviceId = deviceId;
		this.params = params;
		this.time = time;
		this.isDone = isDone;
	}
	
	public int getId() {
		return id;
	}
	
	public int getDeviceId() {
		return deviceId;
	}
	
	public String getParams() {
		return params;
	}
	
	public Date getTime() {
		return time;
	}
	
	public boolean isDone() {
		return isDone;
	}
	
}
