package com.agriculture.nct.database.data;

public class Sensor {
	public final static int PH = 1;
	public final static int TEMPERATURE = 2;
	public final static int HUMIDITY = 3;
	public final static int TDS = 4;
	public final static int LIGHT = 5;
	public final static int WATER_LEVEL = 6;
	
	static public String nameByType(int type) {
		switch (type) {
		case PH: return "pH";
		case TEMPERATURE: return "Temperature";
		case HUMIDITY: return "Humidity";
		case TDS: return "Tds";
		case LIGHT: return "Light";
		case WATER_LEVEL: return "Water lever";
		}
		
		return "";
	}
	
	
	
	
	private int id;
	private String name;
	private int deviceId;
	private int type;
	
	public Sensor(int id, String name, int deviceId, int type) {
		this.id = id;
		this.name = name;
		this.deviceId = deviceId;
		this.type = type;
	}
	
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public int getDeviceId() {
		return deviceId;
	}
	
	public int getType() {
		return type;
	}
}
