package com.agriculture.nct.database.data;

import java.util.Date;

public class Device {
	private int id;
	private int frameId;
	private int type;
	private String password;
	private String securityCode;

	public Device(int id, int frameId, int type, String password, String securityCode) {
		this.id = id;
		this.frameId = frameId;
		this.type = type;
		this.password = password;
		this.securityCode = securityCode;
	}
	
	public int getId() {
		return id;
	}
	
	public int getFrameId() {
		return frameId;
	}
	
	public int getType() {
		return type;
	}

	public String getPassword() { return password; }

	public String getSecurityCode() {
		return securityCode;
	}
}
