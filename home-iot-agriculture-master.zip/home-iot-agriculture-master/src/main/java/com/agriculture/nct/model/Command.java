package com.agriculture.nct.model;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
public class Command {
    private int dev_id;

    private int command_no;

    private String actuator_name;

    private String action;

    private int param;
}
