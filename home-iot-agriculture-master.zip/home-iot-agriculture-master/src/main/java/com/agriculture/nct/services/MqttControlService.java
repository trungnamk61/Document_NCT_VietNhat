package com.agriculture.nct.services;

import com.agriculture.nct.model.Command;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Log4j2
@Service
public class MqttControlService implements MqttCallback {
    private static String TAG = "[MQTT_CONTROL]: ";
    //    String control_sub_topic = "nct_control_%d_ack";
    String collect_pub_topic = "nct_control_%d";
    int qos = 2; //AT_LEAST_ONCE
    //String broker = "tcp://iot.eclipse.org:1883";
    private String broker = "tcp://broker.hivemq.com:1883";
    String clientId = "SERVER_CONTROL_SERVICE_ID";

    private MqttClient mqttControl = null;

    public MqttControlService() {
        // TODO Auto-generated constructor stub

        MemoryPersistence persistence = new MemoryPersistence();
        try {
            mqttControl = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            log.info(TAG + "Connecting to broker: " + broker);
            mqttControl.setCallback(this);
            mqttControl.connect(connOpts);
            if(mqttControl.isConnected())
                System.out.println(TAG + "Connected. Ready to send command to devices");
        } catch (MqttException me) {
            log.error("reason " + me.getReasonCode());
            log.error("msg " + me.getMessage());
            log.error("loc " + me.getLocalizedMessage());
            log.error("cause " + me.getCause());
            log.error("excep " + me);
            me.printStackTrace();
        }

    }

    @Override
    public void connectionLost(Throwable arg0) {
        // TODO Auto-generated method stub
        log.warn(TAG + "Connection lost");
        //Nếu mất kết nối thì thực hiện kết nối lại (lặp đến khi kết nối thành công)
        while (!mqttControl.isConnected()) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            try {
                log.info(TAG + "Trying to connect again");
                mqttControl.connect();
                mqttControl.setCallback(this);
            } catch (MqttException me) {
                log.error("reason " + me.getReasonCode());
                log.error("msg " + me.getMessage());
                log.error("loc " + me.getLocalizedMessage());
                log.error("cause " + me.getCause());
                log.error("excep " + me);
                me.printStackTrace();
            }
        }
        log.info(TAG + "Connected again");
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
        // TODO Auto-generated method stub
        //Gửi 1 command packet thành công thì tạo ra một notifications sẽ dùng để thông báo đến control GUI/view
    }

    public ResponseEntity publishCommand(Command command) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            mqttControl.publish(String.format(collect_pub_topic, command.getDev_id()), mapper.writeValueAsString(command).getBytes(), qos, true);
            log.info(TAG + "Published to the device_id " + command.getDev_id());
        } catch (MqttException me) {
            log.error(TAG + "Failed to publish control command.");
            me.printStackTrace();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return ResponseEntity.ok(command);
    }
}

